/*
  ANZU — منطق لوحة التحكم
  الاسم يُقرأ ديناميكياً من بيانات المستخدم (مثلاً بعد تسجيل الدخول)
  بدل ما يكون مكتوب يدوياً بالكود.
*/

document.addEventListener("DOMContentLoaded", () => {
  renderGreeting();
  renderDate();
  initNavTabs();
  initQuickNote();
});

/* ===== الترحيب الديناميكي — Dynamic greeting =====
   يقرأ اسم المستخدم من localStorage (تحطه صفحة الدخول عند نجاح الدخول).
   لما تربط النظام بباكند حقيقي، استبدل getStoredUserName() بنداء API
   يرجع بيانات المستخدم المسجل دخوله. */

function renderGreeting() {
  const el = document.querySelector("[data-user-greeting]");
  if (!el) return;

  const name = getStoredUserName();
  el.textContent = name ? `أهلاً، ${name}.` : "أهلاً بيك.";
}

function getStoredUserName() {
  try {
    return localStorage.getItem("anzu_user_name") || "";
  } catch {
    return "";
  }
}

/* ===== التاريخ — Date label ===== */

function renderDate() {
  const el = document.querySelector("[data-today-date]");
  if (!el) return;

  const formatter = new Intl.DateTimeFormat("ar", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
  el.textContent = formatter.format(new Date());
}

/* ===== تبديل التابات — Nav tab switching ===== */

function initNavTabs() {
  const tabs = document.querySelectorAll("[data-nav-tab]");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("is-active"));
      tab.classList.add("is-active");
      // TODO: عند إضافة صفحات فعلية لكل تاب (المهام، الذاكرة...)، وجّه هنا
      // مثلاً: window.location.href = tab.dataset.navTab + '.html';
    });
  });
}

/* ===== الملاحظة السريعة — Quick note =====
   حالياً تُحفظ محلياً بالمتصفح فقط. اربطها بنداء API عند تجهيز الباكند. */

function initQuickNote() {
  const input = document.querySelector("[data-quick-note]");
  const saveBtn = document.querySelector("[data-save-note]");
  if (!input || !saveBtn) return;

  const saved = localStorageGet("anzu_quick_note", "");
  if (saved) input.value = saved;

  saveBtn.addEventListener("click", () => {
    localStorageSet("anzu_quick_note", input.value);
    // TODO: استبدل هذا بنداء API لحفظ الملاحظة على السيرفر
    saveBtn.textContent = "تم الحفظ ✓";
    setTimeout(() => (saveBtn.textContent = "حفظ"), 1500);
  });
}

/* ===== أدوات مساعدة — Small helpers ===== */

function localStorageGet(key, fallback) {
  try {
    return localStorage.getItem(key) || fallback;
  } catch {
    return fallback;
  }
}

function localStorageSet(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* ignore */
  }
}
